keywords = {
    "baoule": ["wɛ", "ɖɔhɔ"],
    "dioula": ["ka", "bɛ", "fɔ"]
}
def detect_language(text):
    text = text.lower()
    for lang, kws in keywords.items():
        if any(kw in text for kw in kws):
            return lang
    return "fr"
