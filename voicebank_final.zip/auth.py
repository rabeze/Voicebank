_auth_attempts = {}
def is_authenticated(name, pin):
    if name.lower() == "jean" and pin == "1234":
        return True, "Authentification réussie."
    return False, "Échec de l'authentification."
