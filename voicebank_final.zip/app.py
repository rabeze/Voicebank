from flask import Flask, render_template, request, jsonify, session
from flask_session import Session
from utils.language_detect import detect_language
from auth import is_authenticated
from quiz import get_random_question, check_answer
import json

app = Flask(__name__)
app.secret_key = "voicebank_secret_key"
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

with open("static/data/accounts.json", "r") as f:
    accounts = json.load(f)

responses = {
    "fr": {
        "welcome": "Bienvenue. Veuillez vous identifier avec votre prénom et code PIN.",
        "auth_ok": "Authentification réussie.",
        "auth_fail": "Authentification échouée.",
        "solde": "Votre solde est de {balance} francs CFA.",
        "ouvrir": "Votre demande d'ouverture de compte a été prise en compte.",
        "transfert_ask_to": "À qui souhaitez-vous transférer de l'argent ?",
        "transfert_ask_amount": "Quel montant souhaitez-vous envoyer à {name} ?",
        "transfert_confirm": "Transfert de {amount} francs à {name} confirmé.",
        "conseiller": "Veuillez patienter, un conseiller va vous répondre.",
        "not_understood": "Je n'ai pas compris votre demande.",
        "amount_not_understood": "Je n'ai pas compris le montant. Veuillez répéter."
    }
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/voice", methods=["POST"])
def voice():
    data = request.json
    text = data.get("text", "").lower()

    if "context" not in session:
        session["context"] = {"state": "awaiting_auth", "lang": "fr"}

    context = session["context"]
    lang = detect_language(text)
    context["lang"] = lang
    r = responses.get(lang, responses["fr"])
    response = ""

    if context["state"] == "awaiting_auth":
        parts = text.split()
        if len(parts) >= 2:
            name, pin = parts[0], parts[-1]
            auth_ok, msg = is_authenticated(name, pin)
            if auth_ok:
                context["client_name"] = name
                context["state"] = "idle"
                for acc in accounts["clients"]:
                    if acc["name"].lower() == name.lower():
                        context["balance"] = acc["balance"]
                response = r["auth_ok"]
            else:
                response = msg
        else:
            response = r["welcome"]

    elif context["state"] == "idle":
        if "solde" in text:
            response = r["solde"].format(balance=context.get("balance", 0))
        elif "ouvrir" in text:
            response = r["ouvrir"]
        elif "transférer" in text or "envoyer" in text:
            context["state"] = "awaiting_transfer_to"
            response = r["transfert_ask_to"]
        elif "quiz" in text:
            question, answers = get_random_question(lang)
            context["state"] = "awaiting_quiz_answer"
            context["quiz_answers"] = answers
            response = question
        else:
            response = r["not_understood"]

    elif context["state"] == "awaiting_transfer_to":
        context["transfer_to"] = text
        context["state"] = "awaiting_transfer_amount"
        response = r["transfert_ask_amount"].format(name=text)

    elif context["state"] == "awaiting_transfer_amount":
        import re
        match = re.search(r"\d+", text)
        if match:
            amount = match.group()
            context["state"] = "idle"
            response = r["transfert_confirm"].format(amount=amount, name=context["transfer_to"])
        else:
            response = r["amount_not_understood"]

    elif context["state"] == "awaiting_quiz_answer":
        if check_answer(text, context.get("quiz_answers", [])):
            response = "Bonne réponse !"
        else:
            response = "Mauvaise réponse."
        context["state"] = "idle"

    session["context"] = context
    return jsonify({"response": response, "lang": lang})

if __name__ == "__main__":
    app.run(debug=True)
