def get_random_question(lang): return ("Qu'est-ce que la blockchain ?", ["blockchain", "registre", "chaîne"])
def check_answer(user_input, valid): return any(ans in user_input.lower() for ans in valid)
